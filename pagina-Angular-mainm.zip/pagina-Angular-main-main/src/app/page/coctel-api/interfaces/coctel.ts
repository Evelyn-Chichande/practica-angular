export interface cocteles {
    drinks: { [key: string]: null | string }[];
}
